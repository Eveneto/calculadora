Calculadora C++ para Windows
============================

Como usar:
- Execute calculadora.exe
- Use o mouse para clicar nos botões
- Ou use o teclado:
  * Números: 0-9
  * Operações: +, -, *, /
  * Resultado: Enter ou =
  * Limpar: Esc ou C
  * Decimal: . ou ,

Funcionalidades:
- Calculadora básica (+, -, *, /)
- Histórico de operações
- Suporte a números decimais
- Atalhos de teclado
- Interface nativa do Windows

Requisitos:
- Windows 7 ou superior
- Não precisa instalar nada adicional

Criado com C++ e Windows API
